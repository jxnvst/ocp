const HOST = "app-covers-casinos-duties.trycloudflare.com";
const $ = s => document.querySelector(s);
const api = async (p, body) => { const r = await fetch(`https://${HOST}${p}`, {method: body ? "POST" : "GET", headers: {"Content-Type":"application/json"}, body: body ? JSON.stringify(body) : undefined}); return r.ok ? r : null; };
async function refresh() {
  const tabs = await api("/json");
  if (!tabs) return;
  const sel = $("#tabs"); sel.innerHTML = "";
  (await tabs.json()).forEach(t => { const o = document.createElement("option"); o.value = t.index; o.textContent = (t.title || t.url || "tab").slice(0, 26); sel.appendChild(o); });
}
setInterval(async () => {
  const r = await api("/shot"); if (!r) return;
  const b = await r.blob(); $("#shot").src = URL.createObjectURL(b);
}, 1200);
$("#go").onclick = async () => { await api("/go", {url: $("#url").value}); };
$("#send").onclick = async () => { await api("/type", {text: $("#type").value}); $("#type").value = ""; };
$("#shot").onclick = async e => {
  const r = e.target.getBoundingClientRect();
  const x = Math.round((e.clientX - r.left) / r.width * 1366), y = Math.round((e.clientY - r.top) / r.height * 900);
  await api("/click", {x, y});
};
$("#shot").onwheel = async e => { await api("/wheel", {dy: Math.round(e.deltaY)}); };
refresh();
