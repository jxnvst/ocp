
// OCP Browser Agent v5 - Claude-faithful: chrome.debugger (CDP) drives YOUR browser.
const WSS = "wss://control.propertynexus.pro/browser/ws";
let ws = null; let attempts = 0; let tabId = null; let debuggerAttached = false;

function connect() {
  if (ws && (ws.readyState === 0 || ws.readyState === 1)) return;
  try { ws = new WebSocket(WSS); } catch (e) { ws = null; schedule(); return; }
  ws.onopen = () => { attempts = 0; pushState(); };
  ws.onclose = () => { debuggerAttached = false; ws = null; schedule(); };
  ws.onerror = () => { try { ws.close(); } catch (e) {} };
  ws.onmessage = (ev) => { try { handle(JSON.parse(ev.data)); } catch (e) {} };
}
function schedule() { const d = Math.min(2000 * Math.pow(1.5, attempts++), 30000); setTimeout(connect, d); }
function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }

async function activeTab() {
  const t = await chrome.tabs.query({ active: true, currentWindow: true });
  if (t[0]) return t[0];
  const all = await chrome.tabs.query({ active: true }); return all[0];
}
function pushState() {
  chrome.tabs.query({ active: true, currentWindow: true }).then((t) => {
    if (t[0]) send({ type: "tabstate", state: { tabId: t[0].id, title: t[0].title, url: t[0].url } });
  }).catch(() => {});
}

// ---- CDP via chrome.debugger ----
function attach(tab) {
  return new Promise((resolve, reject) => {
    if (debuggerAttached && tabId === tab.id) return resolve();
    if (debuggerAttached) chrome.debugger.detach({ tabId });
    debuggerAttached = false;
    chrome.debugger.attach({ tabId: tab.id }, "1.3", () => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      debuggerAttached = true; tabId = tab.id;
      chrome.debugger.sendCommand({ tabId: tab.id }, "Page.enable", {}, () => {
        chrome.debugger.sendCommand({ tabId: tab.id }, "Runtime.enable", {}, () => resolve());
      });
    });
  });
}
function cdp(tab, method, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand({ tabId: tab.id }, method, params, (res) => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      resolve(res);
    });
  });
}
async function bringFront(tab) {
  try {
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId) await chrome.windows.update(tab.windowId, { focused: true });
    if (debuggerAttached && tabId === tab.id) await cdp(tab, "Page.bringToFront");
  } catch (e) {}
}

// Flash a cursor marker at (x,y) so you can watch where it clicks.
async function cursor(tab, x, y, click) {
  try {
    if (!debuggerAttached || tabId !== tab.id) return;
    const fx = click
      ? `(function(){const d=document.createElement('div');d.id='__ocpc';d.style.cssText='position:fixed;left:${x-8}px;top:${y-8}px;width:16px;height:16px;border:2px solid #c9a227;border-radius:50%;background:rgba(201,162,39,.3);z-index:2147483647;pointer-events:none;box-shadow:0 0 12px rgba(201,162,39,.9)';document.documentElement.appendChild(d);setTimeout(()=>d.remove(),900)})();`
      : `(function(){let d=document.getElementById('__ocpm');if(!d){d=document.createElement('div');d.id='__ocpm';d.style.cssText='position:fixed;top:0;left:${x}px;width:2px;height:22px;background:#c9a227;border-radius:2px;z-index:2147483647;pointer-events:none;transition:top .15s';document.documentElement.appendChild(d);}d.style.top=${y}px;})();`;
    await cdp(tab, "Runtime.evaluate", { expression: fx });
  } catch (e) {}
}

async function handle(m) {
  const reply = (data, error) => send({ id: m.id, data, error });
  try {
    const tab = await activeTab();
    if (m.t !== "shot") await bringFront(tab);
    await attach(tab);
    switch (m.t) {
      case "shot": {
        const r = await cdp(tab, "Page.captureScreenshot", { format: "png" });
        return reply(r.data);
      }
      case "go":
        await chrome.tabs.update(tab.id, { url: m.url }); reply("ok"); break;
      case "click":
        await cursor(tab, m.x, m.y, true);
        await cdp(tab, "Input.dispatchMouseEvent", { type: "mousePressed", x: m.x, y: m.y, button: "left", clickCount: 1 });
        await cdp(tab, "Input.dispatchMouseEvent", { type: "mouseReleased", x: m.x, y: m.y, button: "left", clickCount: 1 });
        reply("ok"); break;
      case "type":
        await cdp(tab, "Input.insertText", { text: m.text }); reply("ok"); break;
      case "enter":
        for (const t of ["keyDown", "keyUp"]) await cdp(tab, "Input.dispatchKeyEvent", { type: t, key: "Enter", code: "Enter", windowsVirtualKeyCode: 13 });
        reply("ok"); break;
      case "eval": {
        const r = await cdp(tab, "Runtime.evaluate", { expression: m.expression || "undefined", returnByValue: true });
        let v = r && r.result ? r.result.value : undefined;
        reply(v === undefined ? null : (typeof v === "object" ? JSON.stringify(v) : String(v))); break;
      }
      case "focus": await bringFront(tab); reply("ok"); break;
      default: reply(null, "unknown op " + m.t);
    }
  } catch (e) { reply(null, String(e.message || e).slice(0, 160)); }
}

// Claude-style keepalive: ping every 30s; alarms wake a suspended worker.
chrome.alarms.onAlarm.addListener((a) => { if (a.name === "keepalive") { connect(); pushState(); } });
chrome.alarms.create("keepalive", { periodInMinutes: 0.5 });
chrome.runtime.onStartup.addListener(() => connect());
chrome.tabs.onActivated.addListener(pushState);
chrome.tabs.onUpdated.addListener(pushState);
setInterval(() => { if (ws && ws.readyState === 1) send({ type: "ping" }); }, 30000);
connect();
