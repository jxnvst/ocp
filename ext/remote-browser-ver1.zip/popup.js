const HOST = "roughly-nextel-federation-hip.trycloudflare.com";
let ws = null, tabId = null;
const $ = s => document.querySelector(s);
async function api(path) { const r = await fetch(`https://${HOST}${path}`); return r.json(); }
async function send(cmd, params={}) { if (!ws) return; ws.send(JSON.stringify({id: ++send.id, method: cmd, params})); } send.id = 0;
async function pickTab(id) {
  tabId = id; const tabs = await api("/json");
  const t = tabs.find(x => x.id === id) || tabs.find(x => x.type === "page");
  if (ws) { ws.close(); ws = null; }
  ws = new WebSocket((t.webSocketDebuggerUrl || "").replace("ws://","wss://"));
  ws.onopen = () => { send("Page.enable"); send("Runtime.enable"); shot(); };
  ws.onmessage = e => { const m = JSON.parse(e.data); if (m.id === send.id && m.result && m.result.data) { const img = $("#shot"); img.src = "data:image/png;base64," + m.result.data; } };
}
function shot() { send("Page.captureScreenshot", {format:"png"}); }
async function refresh() {
  const tabs = await api("/json");
  const sel = $("#tabs"); sel.innerHTML = "";
  tabs.filter(t => t.type === "page").forEach(t => {
    const o = document.createElement("option"); o.value = t.id;
    o.textContent = (t.title || t.url || "tab").slice(0, 28); sel.appendChild(o);
  });
  if (!tabId && sel.options.length) pickTab(sel.value);
  else if (tabId) pickTab(tabId);
}
setInterval(shot, 1200);
$("#go").onclick = () => { send("Page.navigate", {url: $("#url").value}); };
$("#tabs").onchange = e => pickTab(e.target.value);
$("#send").onclick = () => {
  const txt = $("#type").value; if (!txt) return;
  send("Input.insertText", {text: txt}); $("#type").value = "";
};
$("#shot").onclick = e => {
  const r = e.target.getBoundingClientRect();
  const x = Math.round((e.clientX - r.left) / r.width * 1000), y = Math.round((e.clientY - r.top) / r.height * 1000);
  send("Input.dispatchMouseEvent", {type:"mousePressed", x, y, button:"left", clickCount:1});
  send("Input.dispatchMouseEvent", {type:"mouseReleased", x, y, button:"left", clickCount:1});
};
$("#shot").onwheel = e => { send("Input.dispatchMouseEvent", {type:"mouseWheel", x:500, y:400, deltaX:0, deltaY: e.deltaY*2}); };
refresh();
