
const WS_URL = "wss://limited-december-antonio-frontpage.trycloudflare.com/ws";
let ws = null; let backoff = 1500; let alive = false;
function connect() {
  if (ws && ws.readyState === 0) return;
  if (ws && ws.readyState === 1) { alive = true; return; }
  try { ws = new WebSocket(WS_URL); } catch (e) { ws = null; return; }
  ws.onopen = () => { backoff = 1500; alive = true; pushState(); };
  ws.onclose = () => { alive = false; ws = null; setTimeout(connect, backoff = Math.min(backoff * 1.6, 12000)); };
  ws.onmessage = (ev) => { try { handle(JSON.parse(ev.data)); } catch (e) {} };
  ws.onerror = () => { try { ws.close(); } catch (e) {} };
}
function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }
async function activeTab() { const t = await chrome.tabs.query({ active: true, currentWindow: true }); return t[0] || (await chrome.tabs.query({ active: true }))[0]; }
function pushState() {
  chrome.tabs.query({ active: true, currentWindow: true }).then((t) => {
    if (t[0]) send({ type: "tabstate", state: { tabId: t[0].id, title: t[0].title, url: t[0].url } });
  }).catch(() => {});
}
async function shot() { const win = await chrome.windows.getLastFocused(); const ds = await chrome.tabs.captureVisibleTab(win.id, { format: "png" }); return ds.replace(/^data:image\/png;base64,/, ""); }
async function run(fn, args) { const tab = await activeTab(); const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: fn, args }); return r ? r.result : undefined; }
async function handle(m) {
  const reply = (data, error) => send({ id: m.id, data, error });
  try {
    switch (m.t) {
      case "shot": return reply(await shot());
      case "go": await chrome.tabs.update((await activeTab()).id, { url: m.url }); reply("ok"); break;
      case "click":
        await run((x, y) => { const e = document.elementFromPoint(x, y); if (!e) return "none"; e.click(); return (e.tagName||"") + "|" + (e.id||""); }, [m.x, m.y]);
        reply("ok"); break;
      case "type":
        await run((txt) => {
          const e = document.activeElement; if (!e) return "no-focus";
          const p = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value") || Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value");
          if (p && p.set) p.set.call(e, (e.value||"") + txt); else e.value = (e.value||"") + txt;
          e.dispatchEvent(new Event("input", { bubbles: true }));
          e.dispatchEvent(new Event("change", { bubbles: true }));
          return "typed:" + txt.length;
        }, [m.text]);
        reply("ok"); break;
      case "enter":
        await run(() => { const e = document.activeElement; if (e) e.dispatchEvent(new KeyboardEvent("keydown", { key:"Enter", code:"Enter", bubbles:true, keyCode:13 })); });
        reply("ok"); break;
      case "eval": reply(await run((x) => { try { return JSON.stringify(eval(x)); } catch (e) { return "ERR:" + e.message; } }, [m.expression])); break;
      case "focus": await chrome.windows.update((await activeTab()).windowId, { focused: true }); reply("ok"); break;
      default: reply(null, "unknown op " + m.t);
    }
  } catch (e) { reply(null, String(e.message || e).slice(0, 160)); }
}
// self-wake: MV3 suspends the worker and kills the socket; an alarm wakes us to reconnect.
chrome.alarms.onAlarm.addListener((al) => { if (al.name === "keepalive") { connect(); pushState(); } });
chrome.alarms.create("keepalive", { periodInMinutes: 0.5 });
chrome.runtime.onStartup.addListener(() => connect());
chrome.tabs.onActivated.addListener(pushState);
chrome.tabs.onUpdated.addListener(pushState);
connect();
